function minOperations(){
    
}