function maxLengthBetweenEqualChars(str) {

}