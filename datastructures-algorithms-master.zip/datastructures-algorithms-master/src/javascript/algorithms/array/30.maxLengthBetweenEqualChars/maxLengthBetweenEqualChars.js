function maxLengthBetweenEqualChars(str) {
    
}